# Simulated sensor flow

Original dependency-free educational exercise. It is source only; no live platform review, hosted runtime or production purchase is implied.

## Setup

Install stable Node.js 24.22.3 or later 24.x. No packages or credentials are required. Approximate setup: five minutes after the runtime is installed.

Run the regression first:

```sh
node test.mjs
node simulate.mjs
```

## Included and excluded

Deterministic five-reading simulation. No physical board, firmware flashing, cloud broker or verified hardware operation.

The regression checks the documented CLI from an extracted directory containing spaces and non-ASCII characters, as well as repeatable readings and alert counts.

## License and support

MIT, preserving LICENSE and NOTICE. This self-guided example includes no maintenance contract, paid support, university certification, marks or authorship transfer.
